import json, os, threading

class TradeMapper:
    def __init__(self, file_path="mappings.json"):
        self.file_path = file_path
        self.lock = threading.Lock()
        self.data = self._load()

    def _load(self):
        if os.path.exists(self.file_path):
            try:
                with open(self.file_path, "r") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save(self):
        with self.lock:
            with open(self.file_path, "w") as f:
                json.dump(self.data, f, indent=2)

    def link(self, parent_id, child_name, child_id):
        with self.lock:
            if parent_id not in self.data:
                self.data[parent_id] = {"children": {}}
            self.data[parent_id]["children"][child_name] = {
                "order_id": child_id,
                "status": "open"
            }
            self._save()

    def mark_closed_manual(self, parent_id, child_name):
        with self.lock:
            if parent_id in self.data and child_name in self.data[parent_id]["children"]:
                self.data[parent_id]["children"][child_name]["status"] = "closed_manual"
                self._save()

    def mark_closed_system(self, parent_id, child_name):
        with self.lock:
            if parent_id in self.data and child_name in self.data[parent_id]["children"]:
                self.data[parent_id]["children"][child_name]["status"] = "closed_system"
                self._save()

    def get_child_orders(self, parent_id):
        if parent_id in self.data:
            return list(self.data[parent_id]["children"].items())
        return []

    def all_mappings(self):
        return self.data
