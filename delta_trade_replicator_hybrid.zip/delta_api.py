import requests, hmac, hashlib, time, json

class DeltaAPI:
    BASE_URL = "https://api.delta.exchange"

    def __init__(self, api_key, api_secret):
        self.api_key = api_key
        self.api_secret = api_secret

    def _sign(self, method, path, params=""):
        timestamp = str(int(time.time() * 1000))
        message = timestamp + method + path + params
        signature = hmac.new(
            (self.api_secret or "").encode(), message.encode(), hashlib.sha256
        ).hexdigest()
        return timestamp, signature

    def _request(self, method, endpoint, params=None):
        path = f"/v2/{endpoint}"
        url = self.BASE_URL + path
        params_str = "" if not params else json.dumps(params)
        timestamp, signature = self._sign(method, path, params_str)
        headers = {
            "api-key": self.api_key,
            "timestamp": timestamp,
            "signature": signature,
            "Content-Type": "application/json"
        }
        resp = requests.request(method, url, headers=headers, json=params, timeout=10)
        try:
            return resp.json()
        except Exception:
            return {"error": "non-json-response", "status_code": resp.status_code, "text": resp.text}
