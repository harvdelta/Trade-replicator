import threading, time, uuid, json, os
from trade_mapper import TradeMapper

class TradeReplicator:
    def __init__(self, parent_client, children_clients, config, logger=None):
        self.parent = parent_client
        self.children = children_clients
        self.mapper = TradeMapper()
        self.mode = config.get("mode", "test")
        self.poll_interval = config.get("poll_interval_seconds", 3)
        self.running = False
        self._thread = None
        self.logs = []
        self.lock = threading.Lock()
        self._seen_parent_orders = set()

    def log(self, msg):
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{ts}] {msg}"
        with self.lock:
            self.logs.append(entry)
        print(entry)

    def start(self):
        if self.running:
            return
        self.running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        self.log("Replicator started")

    def stop(self):
        self.running = False
        self.log("Replicator stopped")

    def _fetch_parent_orders_live(self):
        # Placeholder for live parent API polling.
        # In Phase 1, the parent client may be real; implement GET /orders or relevant endpoint here.
        # For safety, we do not place child orders in live mode by default.
        return []

    def _simulate_fetch_parent_orders(self):
        sample = [
            {"id": "P1001", "symbol": "BTCUSD", "side": "buy", "size": 100},
            {"id": "P1002", "symbol": "ETHUSD", "side": "sell", "size": 50}
        ]
        new = []
        for o in sample:
            if o["id"] not in self._seen_parent_orders:
                new.append(o)
                self._seen_parent_orders.add(o["id"])
        return new

    def _run_loop(self):
        while self.running:
            try:
                if self.mode == "test":
                    parent_orders = self._simulate_fetch_parent_orders()
                else:
                    parent_orders = self._fetch_parent_orders_live()
                for order in parent_orders:
                    self._handle_parent_new_order(order)
            except Exception as e:
                self.log(f"Error in run loop: {e}")
            time.sleep(self.poll_interval)

    def _handle_parent_new_order(self, parent_order):
        self.log(f"Detected parent order: {parent_order}")
        for name, info in self.children.items():
            qty = parent_order.get("size", 0) * info.get("multiplier", 1.0)
            if self.mode == "test":
                fake_child_id = f"{parent_order['id']}_{name}"
                self.mapper.link(parent_order["id"], name, fake_child_id)
                self.log(f"[Sim] Placed child order {fake_child_id} for {name} qty={qty}")
            else:
                # In hybrid mode we do NOT place child orders. We only simulate mapping.
                fake_child_id = f"LIVE_{parent_order['id']}_{name}"
                self.mapper.link(parent_order["id"], name, fake_child_id)
                self.log(f"[Hybrid-Sim] Mapped child order {fake_child_id} for {name} qty={qty}")

    def manual_replicate(self, parent_order):
        self._handle_parent_new_order(parent_order)

    def manual_close(self, parent_order):
        parent_id = parent_order.get("id")
        if not parent_id:
            return
        childs = self.mapper.get_child_orders(parent_id)
        for child_name, child_info in childs:
            status = child_info.get("status")
            if status == "open":
                self.mapper.mark_closed_system(parent_id, child_name)
                self.log(f"[Sim] Closed child order {child_info.get('order_id')} for {child_name}")
            else:
                self.log(f"Skipping close for {child_name}, status={status}")

    def get_status(self):
        return {
            "running": self.running,
            "mode": self.mode,
            "poll_interval": self.poll_interval,
            "logs": list(self.logs)[-200:]
        }

    def get_mappings(self):
        return self.mapper.all_mappings()
