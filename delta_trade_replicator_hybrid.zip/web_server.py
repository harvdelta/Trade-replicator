from flask import Flask, jsonify, request, render_template, send_from_directory
import json, threading, os
from delta_api import DeltaAPI
from replicator import TradeReplicator

BASE_DIR = os.path.dirname(__file__)
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
config = json.load(open(CONFIG_PATH))

def build_parent_client():
    return DeltaAPI(config["parent"].get("api_key"), config["parent"].get("api_secret"))

parent_client = build_parent_client()
children = {}
for name, c in config.get("children", {}).items():
    children[name] = {
        "client": DeltaAPI(c.get("api_key"), c.get("api_secret")),
        "multiplier": c.get("multiplier", 1.0)
    }

replicator = TradeReplicator(parent_client, children, config)

app = Flask(__name__, static_folder="static", template_folder="templates")

@app.route('/dashboard')
def dashboard():
    return render_template("dashboard.html")

@app.route('/api/status')
def api_status():
    return jsonify(replicator.get_status())

@app.route('/api/start', methods=['POST'])
def api_start():
    replicator.start()
    return jsonify({'message': 'started'})

@app.route('/api/stop', methods=['POST'])
def api_stop():
    replicator.stop()
    return jsonify({'message': 'stopped'})

@app.route('/api/mappings')
def api_mappings():
    return jsonify(replicator.get_mappings())

@app.route('/api/replicate_order', methods=['POST'])
def api_replicate_order():
    data = request.json
    replicator.manual_replicate(data)
    return jsonify({'message': 'replicated', 'order': data})

@app.route('/api/close_order', methods=['POST'])
def api_close_order():
    data = request.json
    replicator.manual_close(data)
    return jsonify({'message': 'closed', 'order': data})

@app.route('/api/update_multiplier', methods=['POST'])
def api_update_multiplier():
    payload = request.json
    name = payload.get('child')
    multiplier = float(payload.get('multiplier', 1.0))
    if name in replicator.children:
        replicator.children[name]['multiplier'] = multiplier
        # also update config file
        cfg = json.load(open(CONFIG_PATH))
        cfg['children'][name]['multiplier'] = multiplier
        with open(CONFIG_PATH, 'w') as f:
            json.dump(cfg, f, indent=2)
        return jsonify({'message': 'updated', 'child': name, 'multiplier': multiplier})
    return jsonify({'error': 'child not found'}), 400

@app.route('/api/save_parent_keys', methods=['POST'])
def api_save_parent_keys():
    payload = request.json or {}
    api_key = payload.get('api_key', '').strip()
    api_secret = payload.get('api_secret', '').strip()
    # Save to config.json locally
    cfg = json.load(open(CONFIG_PATH))
    cfg['parent']['api_key'] = api_key
    cfg['parent']['api_secret'] = api_secret
    with open(CONFIG_PATH, 'w') as f:
        json.dump(cfg, f, indent=2)
    # rebuild parent client in memory
    global parent_client, replicator
    parent_client = DeltaAPI(api_key, api_secret)
    replicator.parent = parent_client
    return jsonify({'message': 'saved'})

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(os.path.join(BASE_DIR, 'static'), filename)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
