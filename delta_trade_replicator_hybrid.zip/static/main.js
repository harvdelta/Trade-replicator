const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const statusBox = document.getElementById('statusBox');
const logsBox = document.getElementById('logsBox');
const mappingsBox = document.getElementById('mappingsBox');
const autoRefresh = document.getElementById('autoRefresh');
const themeSelect = document.getElementById('themeSelect');
const keysForm = document.getElementById('keysForm');
const apiKeyInput = document.getElementById('apiKey');
const apiSecretInput = document.getElementById('apiSecret');
const saveStatus = document.getElementById('saveStatus');

let refreshInterval = null;

async function fetchStatus() {
  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    statusBox.textContent = JSON.stringify({running: data.running, mode: data.mode, poll_interval: data.poll_interval}, null, 2);
    logsBox.textContent = (data.logs || []).join('\n');
    // fetch mappings too
    const mres = await fetch('/api/mappings');
    const md = await mres.json();
    mappingsBox.textContent = JSON.stringify(md, null, 2);
  } catch (e) {
    statusBox.textContent = 'Error fetching status: ' + e;
  }
}

startBtn.addEventListener('click', async () => {
  await fetch('/api/start', {method: 'POST'});
  fetchStatus();
});

stopBtn.addEventListener('click', async () => {
  await fetch('/api/stop', {method: 'POST'});
  fetchStatus();
});

keysForm.addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const api_key = apiKeyInput.value.trim();
  const api_secret = apiSecretInput.value.trim();
  saveStatus.textContent = 'Saving...';
  const res = await fetch('/api/save_parent_keys', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({api_key, api_secret})
  });
  const jd = await res.json();
  saveStatus.textContent = jd.message === 'saved' ? 'Saved' : ('Error: ' + JSON.stringify(jd));
  setTimeout(()=> saveStatus.textContent = '', 3000);
});

themeSelect.addEventListener('change', (e) => {
  document.body.setAttribute('data-theme', e.target.value);
});

// auto-refresh
setInterval(() => {
  if (autoRefresh.checked) fetchStatus();
}, 3000);

// initial fetch
fetchStatus();
